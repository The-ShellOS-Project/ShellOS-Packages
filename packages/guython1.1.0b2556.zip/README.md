### **GUYTHON V1.1.0B2556**

Guython is a ***VERY*** simple programming language created with Python.

**PLEASE** read 'grammar.txt' as it contains all syntax on the current version of Guython.

### **Installation**
Installing Guython is very easy!
- Install the 'guython{ver}.zip' file.
- Unzip the file.
- Run the 'guython.py' file.

### **Running external files**
Run an external file by placing your '.guy' or '.gy' file in the same directory as the 'guython.py' file, and then use the command 'guython {fileName}.gy/.guy' in the intepreter.
OR run 'python guython.py {fileName}.gy/.guy' in the cmd prompt or terminal while in the same directory as the 'guython.py' file, for debug mode run 'python guython.py --debug {fileName}.gy/.guy'

### **Requirements**
Requires Pillow, which you can install with 'pip install pillow'.
Better to run the interpreter in Command Prompt because VSCode cannot import Pillow for some reason.

### **Whats New**
- Changed comments from '-hello-' to '{hello}'
- Added 'read' with several modifiers
- Added 'write' with several modifiers
- Added GUI
