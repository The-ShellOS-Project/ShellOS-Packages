import os
import sys
import urllib.request
import importlib
import commands  # Import the commands module

# Global variable for the root directory (the folder where this Python file is located)
ROOT_DIR = os.path.dirname(os.path.realpath(__file__))

# Placeholder for custom-installed packages
# CUSTOM_COMMANDS

def update_commands():
    # URL where the updated commands.py file is hosted 
    url = "https://github.com/FusionCore-Corp/FuadeOS/raw/refs/heads/main/updates/commands.py"
    try:
        print("Fetching update file(s) from", url)
        response = urllib.request.urlopen(url)
        new_commands = response.read().decode('utf-8')
        with open(os.path.join(ROOT_DIR, "commands.py"), "w") as f:
            f.write(new_commands)
        print("Update successful: system has been updated.")
    except Exception as e:
        print("Update failed:", e)


def get_prompt(current_directory):
    if current_directory == ROOT_DIR:
        return "~"
    else:
        rel_path = os.path.relpath(current_directory, ROOT_DIR)
        return os.path.join("~", rel_path)


def shell():
    current_directory = ROOT_DIR
    while True:
        command = input(f"{get_prompt(current_directory)} $ ").strip()

        if not command:
            continue
        if command.lower() == "exit":
            commands.exit_shell(command)
        elif command == "help":
            commands.help()
        elif command == "cd" or command.startswith("cd "):
            if command.strip() == "cd ..":
                if current_directory == ROOT_DIR:
                    print("Already in root directory. Cannot go up further.")
                else:
                    new_directory = os.path.dirname(current_directory)
                    if os.path.commonpath([new_directory, ROOT_DIR]) == ROOT_DIR:
                        current_directory = new_directory
                    else:
                        current_directory = ROOT_DIR
            else:
                current_directory = commands.cd(command, current_directory)
        elif command == "ls":
            commands.ls(command, current_directory)
        elif command == "clear":
            commands.clear()
        elif command == "cat" or command.startswith("cat "):
            commands.cat(command, current_directory)
        elif command == "mkdir" or command.startswith("mkdir "):
            commands.mkdir(command, current_directory)
        elif command == "nano" or command.startswith("nano "):
            commands.nano(command, current_directory)
        elif command == "rm" or command.startswith("rm "):
            commands.rm(command, current_directory)
        elif command == "find" or command.startswith("find "):
            commands.find(command, current_directory)
        elif command == "apt update":
            update_commands()
        elif command.startswith("apt install"):
            commands.apt_install(command)
        elif command.startswith("apt uninstall"):
            commands.apt_uninstall(command)
        elif command == "neofetch":
            commands.neofetch()
        else:
            # Try custom commands installed via apt
            commands.exec_custom(command, current_directory)

# Troubleshooting
def run(command, current_directory):
    print("Cannot run command.")

if __name__ == "__main__":
    etc = importlib.import_module("commands")
    print(f"FuadeOS™ \"{etc.codename}\" ({etc.version})")
    print("Copyright© 2025, FusionCore Corporation™. All rights reserved.")
    print("Type \"help\" for a list of commands.")
    shell()
